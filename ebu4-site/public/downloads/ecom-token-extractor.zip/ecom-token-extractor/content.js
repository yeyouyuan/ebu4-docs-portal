/**
 * e-Cology Token Extractor — Content Script
 * 在页面上显示精美悬浮 Token 面板
 */

(function () {
  'use strict';

  // 防止重复注入
  if (document.getElementById('ecom-token-panel')) return;

  let autoMode = true;
  let isMinimized = false;
  let tokens = [];

  // ===== 创建悬浮面板 =====
  const panel = document.createElement('div');
  panel.id = 'ecom-token-panel';
  panel.innerHTML = `
    <div class="etp-header">
      <div class="etp-logo">
        <svg width="18" height="18" viewBox="0 0 128 128" fill="none">
          <circle cx="64" cy="64" r="64" fill="url(#etpGrad)"/>
          <defs><linearGradient id="etpGrad" x1="0" y1="0" x2="128" y2="128">
            <stop offset="0%" stop-color="#6366f1"/><stop offset="100%" stop-color="#8b5cf6"/>
          </linearGradient></defs>
          <g transform="translate(64,58)" stroke="white" stroke-width="8" stroke-linecap="round" stroke-linejoin="round" fill="none">
            <circle cx="-12" cy="-8" r="18"/>
            <line x1="10" y1="-8" x2="52" y2="-8"/>
            <line x1="52" y1="-8" x2="52" y2="12"/>
            <line x1="38" y1="-8" x2="38" y2="12"/>
          </g>
        </svg>
      </div>
      <span class="etp-title">Token Extractor</span>
      <div class="etp-controls">
        <button class="etp-btn etp-auto-btn" id="etpAutoToggle" title="自动/手动">⚡</button>
        <button class="etp-btn etp-min-btn" id="etpMinToggle" title="最小化">—</button>
      </div>
    </div>
    <div class="etp-body" id="etpBody">
      <div class="etp-status" id="etpStatus">
        <span class="etp-dot"></span>
        <span>扫描中...</span>
      </div>
      <div class="etp-token-list" id="etpTokenList"></div>
      <div class="etp-actions">
        <button class="etp-action-btn etp-refresh" id="etpRefresh">🔄 刷新</button>
        <button class="etp-action-btn etp-copy-all" id="etpCopyAll">📋 全部复制</button>
      </div>
    </div>
  `;
  document.body.appendChild(panel);

  // ===== 事件绑定 =====
  document.getElementById('etpMinToggle').addEventListener('click', () => {
    isMinimized = !isMinimized;
    document.getElementById('etpBody').classList.toggle('etp-hidden', isMinimized);
    panel.classList.toggle('etp-collapsed', isMinimized);
    chrome.storage.local.set({ etpMinimized: isMinimized });
  });

  document.getElementById('etpAutoToggle').addEventListener('click', () => {
    autoMode = !autoMode;
    document.getElementById('etpAutoToggle').textContent = autoMode ? '⚡' : '🔘';
    document.getElementById('etpAutoToggle').title = autoMode ? '自动模式' : '手动模式';
    chrome.storage.local.set({ etpAutoMode: autoMode });
  });

  document.getElementById('etpRefresh').addEventListener('click', () => {
    scanTokens();
  });

  document.getElementById('etpCopyAll').addEventListener('click', () => {
    if (tokens.length > 0) {
      const allText = tokens.map(t => `${t.name}=${t.value};`).join(' ');
      copyText(allText);
    }
  });

  // ===== 核心函数 =====
  function scanTokens() {
    const statusEl = document.getElementById('etpStatus');
    statusEl.innerHTML = '<span class="etp-dot etp-dot-warn"></span><span>扫描中...</span>';

    chrome.runtime.sendMessage({ action: 'scanTokens' }, (resp) => {
      if (resp && resp.tokens) {
        tokens = resp.tokens;
        renderTokens(tokens);
      } else {
        statusEl.innerHTML = '<span class="etp-dot etp-dot-err"></span><span>扫描失败</span>';
      }
    });
  }

  function renderTokens(list) {
    const container = document.getElementById('etpTokenList');
    const statusEl = document.getElementById('etpStatus');

    if (list.length === 0) {
      statusEl.innerHTML = '<span class="etp-dot etp-dot-err"></span><span>未发现 Token</span>';
      container.innerHTML = '<div class="etp-empty">当前页面无有效 Token</div>';
      return;
    }

    statusEl.innerHTML = `<span class="etp-dot etp-dot-ok"></span><span>发现 ${list.length} 个 Token</span>`;

    container.innerHTML = list.map((t, i) => {
      const truncated = t.value.length > 40
        ? t.value.slice(0, 20) + '...' + t.value.slice(-10)
        : t.value;
      const isExpired = t.expires && t.expires * 1000 < Date.now();
      return `
        <div class="etp-token-item ${isExpired ? 'etp-expired' : ''}" data-index="${i}">
          <div class="etp-token-header">
            <span class="etp-token-name">${t.name}</span>
            ${isExpired ? '<span class="etp-badge-expired">已过期</span>' : '<span class="etp-badge-active">有效</span>'}
          </div>
          <div class="etp-token-value" title="${t.value}">${truncated}</div>
          <div class="etp-token-meta">
            <span>${t.domain}</span>
            <span>${t.httpOnly ? '🔒 HttpOnly' : ''} ${t.secure ? '🛡️ Secure' : ''}</span>
          </div>
          <button class="etp-copy-btn" data-value="${escapeAttr(t.name + '=' + t.value + ';')}">📋 复制 Cookie</button>
        </div>
      `;
    }).join('');

    // 绑定复制按钮
    container.querySelectorAll('.etp-copy-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const val = e.currentTarget.dataset.value;
        copyText(val);
        e.currentTarget.textContent = '✅ 已复制';
        setTimeout(() => { e.currentTarget.textContent = '📋 复制'; }, 1500);
      });
    });
  }

  function copyText(text) {
    // 优先用 navigator.clipboard
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).catch(() => fallbackCopy(text));
    } else {
      fallbackCopy(text);
    }
  }

  function fallbackCopy(text) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;left:-9999px;top:-9999px';
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
  }

  function escapeAttr(s) {
    return s.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  // ===== 拖动支持 =====
  let isDragging = false, dragX, dragY;
  const header = panel.querySelector('.etp-header');
  header.addEventListener('mousedown', (e) => {
    if (e.target.tagName === 'BUTTON') return;
    isDragging = true;
    dragX = e.clientX - panel.offsetLeft;
    dragY = e.clientY - panel.offsetTop;
    e.preventDefault();
  });
  document.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    panel.style.left = (e.clientX - dragX) + 'px';
    panel.style.top = (e.clientY - dragY) + 'px';
    panel.style.right = 'auto';
    panel.style.bottom = 'auto';
  });
  document.addEventListener('mouseup', () => { isDragging = false; });

  // ===== 恢复设置 & 启动 =====
  chrome.storage.local.get(['etpMinimized', 'etpAutoMode', 'tokens'], (res) => {
    isMinimized = !!res.etpMinimized;
    autoMode = res.etpAutoMode !== undefined ? res.etpAutoMode : true;

    if (isMinimized) {
      document.getElementById('etpBody').classList.add('etp-hidden');
      panel.classList.add('etp-collapsed');
    }
    document.getElementById('etpAutoToggle').textContent = autoMode ? '⚡' : '🔘';
    document.getElementById('etpAutoToggle').title = autoMode ? '自动模式' : '手动模式';

    // 有缓存先显示
    if (res.tokens && res.tokens.length > 0) {
      tokens = res.tokens;
      renderTokens(tokens);
    }

    // 自动模式立即扫描
    if (autoMode) scanTokens();
  });

  // 监听后台更新
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'tokensUpdated' && autoMode) {
      tokens = msg.tokens;
      renderTokens(tokens);
    }
  });

  // ===== 拖拽到页面边缘自动吸附 =====
  function autoSnap() {
    const rect = panel.getBoundingClientRect();
    const w = window.innerWidth, h = window.innerHeight;
    // 如果靠近右下角就吸附
    if (rect.right > w - 30 && rect.bottom > h - 30) {
      panel.style.left = 'auto';
      panel.style.top = 'auto';
      panel.style.right = '16px';
      panel.style.bottom = '16px';
    }
  }
  window.addEventListener('resize', autoSnap);

})();
